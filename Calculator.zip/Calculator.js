var arr = new Array();

function insert(num)
{
	document.form.textview.value = document.form.textview.value + num;
	if (arr.length == 0) {
		if (typeof num == 'number') {
			arr.push(num);
		}
	}
	else {

	}
	if (num == '&times;') {
		arr.push('*');
	}
	if (num == '&divide;') {
		arr.push('/');
	}
	console.log(arr);
}

function clean() 
{
	document.form.textview.value = "";
	arr = [];
}

function deleteSymbol() 
{
	var string = document.form.textview.value;
	document.form.textview.value = string.substring(0, string.length - 1);
	arr.pop();
}
function equal() 
{
	var string = document.form.textview.value;
	if(string)
	{
		document.form.textview.value = eval(string);
	}
}

function checkDigit(num)
{
	if (num == '+' || num == '-' || num == '/' || num == '*')
		return 0;
	else return 1;
}

function equal_Kek()
{
	var res;
	var op = arr[1];
	switch (op) {
		case '+':
	        res = arr[0] + arr[2];
	        break;
	    case '-':
	        res = arr[0] - arr[2];
	        break;
	    case '*':
	        res = arr[0] * arr[2];
	        break;
		case '/':
			res = arr[0] / arr[2];
			break;
	}
	document.form.textview.value = res;
}	